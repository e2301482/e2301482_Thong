#include "wlan.h"
#include <stdio.h>
#include <stdlib.h>


enum LINE_TYPE what_line(char*); //Read
int wlan_count(FILE*); 
void wlan_analyse(FILE*);
int wlan_number(char*);
char* read_value(char*);
void show_wlan(struct ssid*, int);
void takeAwayNewline(char*);



int main() {
	system(CMD); //run command line
	FILE* fp = fopen("./wlan.txt", "r"); //open file to read
	if (fp != NULL) {
		wlan_analyse(fp);
		fclose(fp);
	}
	else printf("Error: wlan.txt file doesn't exist!\n");
	return 0;
	}

int wlan_count(FILE* f)
{
	return 0;
}

void wlan_analyse(FILE* fp)
{
	struct ssid list_ssid[30];
	//read file line by line and search keyword
		char line[CHAR_MAX];
		int i=0;
		enum LINE_TYPE type;
		while (fgets(line, sizeof(line), fp) != '\0') {
			type = what_line(line);
			
			if (type != 0) {
			//list_ssid[i].ssid = 
				if (strlen(line) < 11) printf("%d Hide\n", type);
				else printf("%d %s\n", type, line+type);
			}
				//printf("%d %s\n", type, line);
			i++;
		}
		
}

int wlan_number(char* f)
{
	return 0;
}

char* read_value(char* f)
{
	return 0;
}

void show_wlan(ssid* ssid_list, int num_ssids)
{

	//printf("Found %d WLANS\n", wlan_count());
}

void takeAwayNewline(char* str)
{
}