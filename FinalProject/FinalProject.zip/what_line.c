#include "wlan.h"

enum LINE_TYPE what_line(char* line) {
	if (strstr(line, "BSSID") != '\0') {
		//printf("%s",line);
		return BSSID;
	}
	if (strstr(line, "SSID") != '\0') {
		//printf("%s",line);
		return SSID;
	}
	if (strstr(line, "Signal") != '\0') {
		//printf("%s",line);
		return SIGNAL_STRENGTH;
	}
	if (strstr(line, "Radio type") != '\0') {
		//printf("%s",line);
		return RADIO_TYPE;
	}
	if (strstr(line, "Channel            :") != '\0') {
		//printf("%s",line);
		return CHANNEL;
	}

}