#pragma once
enum LINE_TYPE {
    UNKNOWN = -1,
    SSID = 9,
    NETWORK_TYPE = -1,
    AUTHENTICATION = -1,
    ENCRYPTION = -1,
    BSSID = 30,
    SIGNAL_STRENGTH = 30,
    RADIO_TYPE = 30,
    CHANNEL = 30
};

typedef struct ap {
    char apmac[20]; //MAC address of AP
    int signal_strength; //percentage value
    int channel; //between 1-13 in EU
}ap ;

typedef struct ssid {
    char ssid[30]; //SSID
    int num_ap; //number of APs
    ap aplist[20]; //a list of APs (dynamic)
}ssid ;

#define CMD "netsh wlan show networks mode=bssid > wlan.txt"

